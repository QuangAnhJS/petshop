<?php
require_once("config.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Electro - HTML Ecommerce Template</title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="css/slick.css" />
    <link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="../css/styleForm.css">
    <!-- <link rel="stylesheet" href="../style.css"> -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- link google font -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
        body {
            background: white;
        }
    </style>
</head>

<body>
    <!-- HEADER -->
    <header>
        <!-- TOP HEADER -->
        <div id="top-header">
            <div class="container">
                <ul class="header-links pull-left">
                    <li><a href="#"><i class="fa fa-phone"></i>0999999999</a></li>
                    <li><a href="#"><i class="fa fa-envelope-o"></i> PetShop@email.com</a></li>

                </ul>
                <?php
                if (isset($code) == 1) {
                ?>
                    <ul class="header-links pull-right">
                        <li><a href="blank.php"><i class="fa fa-dollar"></i> USD</a></li>
                        <li><a href="logout.php"><i class="fa fa-user-o"></i>Đăng xuất</a></li>
                    </ul>
                <?php
                } else {
                ?>

                    <ul class="header-links pull-right">

                        <li><a href="login.php"><i class="fa fa-user-o"></i> My Account</a></li>
                    </ul>
                <?php
                }
                ?>
            </div>
        </div>
        <!-- /TOP HEADER -->

        <!-- MAIN HEADER -->
        <div id="header">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <div class="header-logo">
                            <a href="#" class="logo">
                                <img src="./img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                    <!-- /LOGO -->

                    <!-- SEARCH BAR -->
                    <div class="col-md-6">
                        <div class="header-search">
                            <form style="display: flex;     justify-content: center;">
                                <!-- <select class="input-select" id="">
                                    <option value="0">All Category</option>
                               "     <?php
                                        $queryCategory = mysqli_query($conn, "SELECT DISTINCT Category from `product`");
                                        while ($rowCategory = mysqli_fetch_assoc($queryCategory)) {
                                        ?>
                                    <option value="1"><?= $rowCategory['Category']; ?></option>

                                    <?php
                                        }
                                    ?>"
                                </select> -->
                                <input oninput="searchBy(this)" class="input" placeholder="Search here" style="    border-radius: 24px 0 0 24px;">
                                <button class="search-btn">Search</button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->

                    <!-- ACCOUNT -->
                    <div class="col-md-3 clearfix">
                        <div class="header-ctn">
                            <!-- Wishlist -->
                           
                            <!-- Cart -->


                            <div class="dropdown">
                                <a id="cart-dropdown-toggle" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span>Your Cart</span>
                                    <?php
                                    $id = isset($_SESSION['id'])?$_SESSION['id']:null;
                                
                                        $query = mysqli_query($conn, "SELECT * from `cart` where `UserID`='$id'");

                                        $num = mysqli_num_rows($query);
                                        if ($num > 0) {
                                            $nums = $num;
                                            echo '<div class="qty">' . $nums . '</div>';
                                        } else {
                                            echo '<div class="qty">0</div>';
                                        }
                           
                                    ?>
                                </a>
                                <div id="cart-dropdown" class="cart-dropdown">
                                    <!-- Nội dung giỏ hàng -->
                                </div>
                            </div>

                            <!-- /Cart -->

                            <!-- Menu Toogle -->
                            <div class="menu-toggle">
                                <a href="#">
                                    <i class="fa fa-bars"></i>
                                    <span>Menu</span>
                                </a>
                            </div>
                            <!-- /Menu Toogle -->
                        </div>
                    </div>
                    <!-- /ACCOUNT -->
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <nav id="navigation">
            <!-- container -->
            <div class="container">
                <!-- responsive-nav -->
                <div id="responsive-nav">
                    <!-- NAV -->
                    <ul class="main-nav nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li>

                    </ul>
                    <!-- /NAV -->
                </div>
                <!-- /responsive-nav -->
            </div>
            <!-- /container -->
        </nav>
        <!-- /MAIN HEADER -->
    </header>